import LoginForm from "@/login-form"

export default function Home() {
  return <LoginForm />
}
